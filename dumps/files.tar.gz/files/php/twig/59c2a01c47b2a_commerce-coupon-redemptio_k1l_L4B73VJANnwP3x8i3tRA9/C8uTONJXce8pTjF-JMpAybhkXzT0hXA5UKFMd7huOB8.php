<?php

/* themes/custom/commerce_2_demo/templates/commerce/commerce-coupon-redemption-form.html.twig */
class __TwigTemplate_a6da61fd8cd37738d6c7cf900b1a8dd2ba8451a35e78c092632c3fa83c71a37b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("if" => 16, "for" => 28);
        $filters = array("without" => 14, "length" => 16, "t" => 20, "render" => 20, "first" => 28);
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('if', 'for'),
                array('without', 'length', 't', 'render', 'first'),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 14
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_without(($context["form"] ?? null), "coupons"), "html", null, true));
        echo "

";
        // line 16
        if (twig_length_filter($this->env, $this->getAttribute(($context["form"] ?? null), "coupons", array()))) {
            // line 17
            echo "  ";
            if (($this->getAttribute(($context["form"] ?? null), "#cardinality", array(), "array") == 1)) {
                // line 18
                echo "    <div class=\"coupon-redemption-form__coupons coupon-redemption-form__coupons--single\">
      <p>
        <br>";
                // line 20
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("You applied the coupon %code to the order.", array("%code" => $this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->getAttribute($this->getAttribute($this->getAttribute(($context["form"] ?? null), "coupons", array()), 0, array()), "code", array()))))));
                echo "
      </p>
      ";
                // line 22
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["form"] ?? null), "coupons", array()), 0, array()), "remove_button", array()), "html", null, true));
                echo "
    </div>
  ";
            } else {
                // line 25
                echo "    <div class=\"coupon-redemption-form__coupons coupon-redemption-form__coupons--multiple\">
      <h3> ";
                // line 26
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Applied coupons")));
                echo " </h3>
      <table>
        ";
                // line 28
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["form"] ?? null), "coupons", array()));
                foreach ($context['_seq'] as $context["key"] => $context["coupon"]) {
                    if ((twig_first($this->env, $context["key"]) != "#")) {
                        // line 29
                        echo "          <tr>
            <td> ";
                        // line 30
                        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($context["coupon"], "code", array()), "html", null, true));
                        echo " </td>
            <td> ";
                        // line 31
                        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($context["coupon"], "remove_button", array()), "html", null, true));
                        echo " </td>
          </tr>
        ";
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['key'], $context['coupon'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 34
                echo "      </table>
    </div>
  ";
            }
        }
    }

    public function getTemplateName()
    {
        return "themes/custom/commerce_2_demo/templates/commerce/commerce-coupon-redemption-form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 34,  88 => 31,  84 => 30,  81 => 29,  76 => 28,  71 => 26,  68 => 25,  62 => 22,  57 => 20,  53 => 18,  50 => 17,  48 => 16,  43 => 14,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/commerce_2_demo/templates/commerce/commerce-coupon-redemption-form.html.twig", "/home/drupalcommerce/www/demo/web/themes/custom/commerce_2_demo/templates/commerce/commerce-coupon-redemption-form.html.twig");
    }
}
