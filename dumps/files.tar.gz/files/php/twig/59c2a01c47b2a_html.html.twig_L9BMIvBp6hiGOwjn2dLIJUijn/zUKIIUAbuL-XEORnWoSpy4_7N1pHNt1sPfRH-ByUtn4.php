<?php

/* themes/custom/commerce_2_demo/templates/pages/html.html.twig */
class __TwigTemplate_eb12ab807d22764d132df73885020fcf1191fada2205bff59b8cb30938b1f929 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("set" => 27);
        $filters = array("clean_class" => 29, "raw" => 41, "safe_join" => 42, "t" => 97);
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('set'),
                array('clean_class', 'raw', 'safe_join', 't'),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 27
        $context["body_classes"] = array(0 => ((        // line 28
($context["logged_in"] ?? null)) ? ("user-logged-in") : ("")), 1 => (( !        // line 29
($context["root_path"] ?? null)) ? ("path-frontpage") : (("path-" . \Drupal\Component\Utility\Html::getClass(($context["root_path"] ?? null))))), 2 => ((        // line 30
($context["node_type"] ?? null)) ? (("page-node-type-" . \Drupal\Component\Utility\Html::getClass(($context["node_type"] ?? null)))) : ("")), 3 => ((        // line 31
($context["db_offline"] ?? null)) ? ("db-offline") : ("")), 4 => ((        // line 32
($context["page_title"] ?? null)) ? (("page-title-" . \Drupal\Component\Utility\Html::getClass(($context["page_title"] ?? null)))) : ("")), 5 => ((        // line 33
($context["current_path"] ?? null)) ? (("path" . \Drupal\Component\Utility\Html::getClass(($context["current_path"] ?? null)))) : ("")), 6 => ((        // line 34
($context["term_vocabulary"] ?? null)) ? (("term-vocab-" . \Drupal\Component\Utility\Html::getClass(($context["term_vocabulary"] ?? null)))) : ("")), 7 => ((        // line 35
($context["term_name"] ?? null)) ? (("term-" . \Drupal\Component\Utility\Html::getClass(($context["term_name"] ?? null)))) : ("")));
        // line 38
        echo "<!DOCTYPE html>
<html";
        // line 39
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["html_attributes"] ?? null), "html", null, true));
        echo ">
  <head>
    <head-placeholder token=\"";
        // line 41
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(($context["placeholder_token"] ?? null)));
        echo "\">
    <title>";
        // line 42
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->env->getExtension('Drupal\Core\Template\TwigExtension')->safeJoin($this->env, ($context["head_title"] ?? null), " | ")));
        echo "</title>
    <css-placeholder token=\"";
        // line 43
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(($context["placeholder_token"] ?? null)));
        echo "\">
    <js-placeholder token=\"";
        // line 44
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(($context["placeholder_token"] ?? null)));
        echo "\">
    ";
        // line 46
        echo "    <link href=\"https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300i|Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto+Slab:700|Love+Ya+Like+A+Sister\" rel=\"stylesheet\">
    ";
        // line 48
        echo "    <link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"/apple-touch-icon.png\">
    <link rel=\"icon\" type=\"image/png\" sizes=\"32x32\" href=\"/favicon-32x32.png\">
    <link rel=\"icon\" type=\"image/png\" sizes=\"16x16\" href=\"/favicon-16x16.png\">
    <link rel=\"manifest\" href=\"/manifest.json\">
    <link rel=\"mask-icon\" href=\"/safari-pinned-tab.svg\" color=\"#5bbad5\">
    <meta name=\"theme-color\" content=\"#ffffff\">
    ";
        // line 55
        echo "    <meta name=\"robots\" content=\"noindex, nofollow, noarchive, noimageindex\">
    <meta name=\"googlebot\" content=\"noindex, nofollow, noarchive, nosnippet, noimageindex\">

    ";
        // line 59
        echo "    <script type=\"text/javascript\" src=\"//platform-api.sharethis.com/js/sharethis.js#property=591c6fb6c3c43c0017f5dfe0&product=inline-share-buttons\"></script>

    ";
        // line 62
        echo "    <script>
      (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:630318,hjsv:5};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
      })(window,document,'//static.hotjar.com/c/hotjar-','.js?sv=');
    </script>

      ";
        // line 74
        echo "    <script type=\"text/javascript\">
      window.\$zopim||(function(d,s){var z=\$zopim=function(c){
        z._.push(c)},\$=z.s=
        d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
      _.push(o)};z._=[];z.set._=[];\$.async=!0;\$.setAttribute('charset','utf-8');
        \$.src='//v2.zopim.com/?489qUUs0E89EUo0sNP93u7uChomokWER';z.t=+new Date;\$.
          type='text/javascript';e.parentNode.insertBefore(\$,e)})(document,'script');
    </script>
    ";
        // line 83
        echo "
    ";
        // line 85
        echo "    <script type=\"text/javascript\">
      window.setTimeout(function() {
        \$zopim.livechat.button.show();
        \$zopim.livechat.window.show();
        \$zopim.livechat.bubble.show();
      }, 120000);
    </script>
    ";
        // line 93
        echo "  </head>
  <body";
        // line 94
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["attributes"] ?? null), "addClass", array(0 => ($context["body_classes"] ?? null)), "method"), "html", null, true));
        echo ">
    <div id=\"mobile-overlay\"></div>
    <a href=\"#main-content\" class=\"visually-hidden focusable skip-link\">
      ";
        // line 97
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Skip to main content")));
        echo "
    </a>
    <button type=\"button\" id=\"siteTours-start\" class=\"btn btn-primary fixed-button\" data-toggle=\"modal\" data-target=\"#siteTours\">
      <i class=\"fa fa-star fa-lg\"></i> ";
        // line 100
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Guided Tours")));
        echo "
    </button>
    ";
        // line 102
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["page_top"] ?? null), "html", null, true));
        echo "
    ";
        // line 103
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["page"] ?? null), "html", null, true));
        echo "
    ";
        // line 104
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["page_bottom"] ?? null), "html", null, true));
        echo "
    <js-bottom-placeholder token=\"";
        // line 105
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(($context["placeholder_token"] ?? null)));
        echo "\">
  </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "themes/custom/commerce_2_demo/templates/pages/html.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  164 => 105,  160 => 104,  156 => 103,  152 => 102,  147 => 100,  141 => 97,  135 => 94,  132 => 93,  123 => 85,  120 => 83,  110 => 74,  97 => 62,  93 => 59,  88 => 55,  80 => 48,  77 => 46,  73 => 44,  69 => 43,  65 => 42,  61 => 41,  56 => 39,  53 => 38,  51 => 35,  50 => 34,  49 => 33,  48 => 32,  47 => 31,  46 => 30,  45 => 29,  44 => 28,  43 => 27,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/commerce_2_demo/templates/pages/html.html.twig", "/home/drupalcommerce/www/demo/web/themes/custom/commerce_2_demo/templates/pages/html.html.twig");
    }
}
