<?php

/* themes/custom/commerce_2_demo/templates/nodes/node--homepage-carousel-slide.html.twig */
class __TwigTemplate_79f4b00ff5eafdc59366fa8818c127effe93c4db89509ec62f887d3a40d18b72 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("if" => 16);
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('if'),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 15
        echo "<div class=\"homepage-carousel-slide\">
  ";
        // line 16
        if ((($context["slide_link_url"] ?? null) &&  !$this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_carousel_slide_link", array()), "title", array()))) {
            // line 17
            echo "    <a href=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["slide_link_url"] ?? null), "html", null, true));
            echo "\" class=\"homepage-carousel-slide__link-wrapper\">
  ";
        }
        // line 19
        echo "
  ";
        // line 20
        if (($context["slide_image_url"] ?? null)) {
            // line 21
            echo "    <div class=\"homepage-carousel-slide__image hidden-xs\">
      <img src=\"";
            // line 22
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["slide_image_url"] ?? null), "html", null, true));
            echo "\" alt=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_carousel_image", array()), "alt", array()), "value", array()), "html", null, true));
            echo "\">
    </div>
  ";
        }
        // line 25
        echo "
  <div class=\"homepage-carousel-slide__mobile-image visible-xs-block\">
    ";
        // line 27
        if (($context["slide_mobile_image_url"] ?? null)) {
            // line 28
            echo "      <img src=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["slide_mobile_image_url"] ?? null), "html", null, true));
            echo "\" alt=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_carousel_mobile_image", array()), "alt", array()), "value", array()), "html", null, true));
            echo "\">
    ";
        } elseif (        // line 29
($context["slide_image_url"] ?? null)) {
            // line 30
            echo "      <img src=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["slide_image_url"] ?? null), "html", null, true));
            echo "\" alt=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_carousel_image", array()), "alt", array()), "value", array()), "html", null, true));
            echo "\">
    ";
        }
        // line 32
        echo "  </div>

  ";
        // line 34
        if ((($this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_carousel_slide_title", array()), "value", array()) || $this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_carousel_slide_body", array()), "value", array())) || $this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_carousel_slide_link", array()), "title", array()))) {
            // line 35
            echo "    <div class=\"homepage-carousel-slide__content-wrapper\">
      <div class=\"homepage-carousel-slide__content\">
        ";
            // line 37
            if ($this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_carousel_slide_title", array()), "value", array())) {
                // line 38
                echo "          <div class=\"homepage-carousel-slide__title\">
            <span>";
                // line 39
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_carousel_slide_title", array()), "value", array()), "html", null, true));
                echo "</span>
          </div>
        ";
            }
            // line 42
            echo "
        ";
            // line 43
            if ($this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_carousel_slide_body", array()), "value", array())) {
                // line 44
                echo "          <div class=\"homepage-carousel-slide__body\">
            ";
                // line 45
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_carousel_slide_body", array()), "value", array()), "html", null, true));
                echo "
          </div>
        ";
            }
            // line 48
            echo "
        ";
            // line 49
            if ((($context["slide_link_url"] ?? null) && $this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_carousel_slide_link", array()), "title", array()))) {
                // line 50
                echo "          <div class=\"homepage-carousel-slide__link\">
            <a href=\"";
                // line 51
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["slide_link_url"] ?? null), "html", null, true));
                echo "\" class=\"btn btn-secondary\">";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_carousel_slide_link", array()), "title", array()), "html", null, true));
                echo "</a>
          </div>
        ";
            }
            // line 54
            echo "      </div>
    </div>
  ";
        }
        // line 57
        echo "
  ";
        // line 58
        if ((($context["slide_link_url"] ?? null) &&  !$this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_carousel_slide_link", array()), "title", array()))) {
            // line 59
            echo "    </a>
  ";
        }
        // line 61
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "themes/custom/commerce_2_demo/templates/nodes/node--homepage-carousel-slide.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  158 => 61,  154 => 59,  152 => 58,  149 => 57,  144 => 54,  136 => 51,  133 => 50,  131 => 49,  128 => 48,  122 => 45,  119 => 44,  117 => 43,  114 => 42,  108 => 39,  105 => 38,  103 => 37,  99 => 35,  97 => 34,  93 => 32,  85 => 30,  83 => 29,  76 => 28,  74 => 27,  70 => 25,  62 => 22,  59 => 21,  57 => 20,  54 => 19,  48 => 17,  46 => 16,  43 => 15,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/commerce_2_demo/templates/nodes/node--homepage-carousel-slide.html.twig", "/home/drupalcommerce/www/demo/web/themes/custom/commerce_2_demo/templates/nodes/node--homepage-carousel-slide.html.twig");
    }
}
