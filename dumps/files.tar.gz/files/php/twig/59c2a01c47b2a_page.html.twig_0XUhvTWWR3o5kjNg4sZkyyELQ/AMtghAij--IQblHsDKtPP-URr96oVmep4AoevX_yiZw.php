<?php

/* themes/custom/commerce_2_demo/templates/pages/page.html.twig */
class __TwigTemplate_099e7f87a4656e38cdcfdcd1abb3b6f998a587400a8e56f6f0f9f24b3d41b84b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("set" => 53, "include" => 59, "if" => 66);
        $filters = array();
        $functions = array("render_var" => 53);

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('set', 'include', 'if'),
                array(),
                array('render_var')
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 53
        $context["page_sidebar_rendered"] = $this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->getAttribute(($context["page"] ?? null), "page_sidebar", array()));
        // line 55
        $context["row_class"] = ((($context["page_sidebar_rendered"] ?? null)) ? ("row-eq-height") : (""));
        // line 56
        $context["col_class"] = ((($context["page_sidebar_rendered"] ?? null)) ? ("col-sm-9 col-md-10") : ("col-sm-12"));
        // line 57
        echo "
";
        // line 59
        $this->loadTemplate(((($context["base_path"] ?? null) . ($context["directory"] ?? null)) . "/templates/pages/includes/site_header.html.twig"), "themes/custom/commerce_2_demo/templates/pages/page.html.twig", 59)->display($context);
        // line 61
        echo "
";
        // line 63
        echo "<div class=\"site-content\">
  <div class=\"container\">
    <div class=\"row ";
        // line 65
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["row_class"] ?? null), "html", null, true));
        echo "\">
      ";
        // line 66
        if (($context["page_sidebar_rendered"] ?? null)) {
            // line 67
            echo "        <div class=\"col-sm-3 col-md-2 hidden-xs\">
          <aside class=\"site-sidebar\" role=\"complementary\">
            ";
            // line 69
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "page_sidebar", array()), "html", null, true));
            echo "
          </aside>
        </div>
      ";
        }
        // line 73
        echo "
      <div class=\"";
        // line 74
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["col_class"] ?? null), "html", null, true));
        echo "\">
        <main class=\"content__main-content clearfix\" role=\"main\">
          <div class=\"visually-hidden\"><a id=\"main-content\" tabindex=\"-1\"></a></div>
          ";
        // line 77
        if ($this->getAttribute(($context["page"] ?? null), "highlighted", array())) {
            // line 78
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "highlighted", array()), "html", null, true));
            echo "
          ";
        }
        // line 80
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "above_content", array())) {
            // line 81
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "above_content", array()), "html", null, true));
            echo "
          ";
        }
        // line 83
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "content", array())) {
            // line 84
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "content", array()), "html", null, true));
            echo "
          ";
        }
        // line 86
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "below_content", array())) {
            // line 87
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "below_content", array()), "html", null, true));
            echo "
          ";
        }
        // line 89
        echo "        </main>
      </div>
    </div>
  </div>
</div>
";
        // line 95
        echo "
";
        // line 97
        $this->loadTemplate(((($context["base_path"] ?? null) . ($context["directory"] ?? null)) . "/templates/pages/includes/site_footer.html.twig"), "themes/custom/commerce_2_demo/templates/pages/page.html.twig", 97)->display($context);
    }

    public function getTemplateName()
    {
        return "themes/custom/commerce_2_demo/templates/pages/page.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  132 => 97,  129 => 95,  122 => 89,  116 => 87,  113 => 86,  107 => 84,  104 => 83,  98 => 81,  95 => 80,  89 => 78,  87 => 77,  81 => 74,  78 => 73,  71 => 69,  67 => 67,  65 => 66,  61 => 65,  57 => 63,  54 => 61,  52 => 59,  49 => 57,  47 => 56,  45 => 55,  43 => 53,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/commerce_2_demo/templates/pages/page.html.twig", "/home/drupalcommerce/www/demo/web/themes/custom/commerce_2_demo/templates/pages/page.html.twig");
    }
}
