<?php

/* /themes/custom/commerce_2_demo/templates/pages/includes/site_footer.html.twig */
class __TwigTemplate_d379a5e38b036ba5086b407b9aa72ffb3e2ddd12ab3eade54f56752883d69513 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("set" => 2, "if" => 18, "trans" => 186);
        $filters = array("t" => 79, "date" => 93);
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('set', 'if', 'trans'),
                array('t', 'date'),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 2
        $context["site_logo_icon_url"] = ((($context["base_path"] ?? null) . ($context["directory"] ?? null)) . "/gfx/logo-icon.svg");
        // line 3
        echo "
<footer class=\"site-footer\">
  <div class=\"container\">
    ";
        // line 7
        echo "    <div class=\"site-footer__top\">
      <div class=\"row\">
        <div class=\"col-xs-12 col-sm-6\">
          ";
        // line 11
        echo "          <div class=\"site-footer__logo\">
            <a href=\"";
        // line 12
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["front_page"] ?? null), "html", null, true));
        echo "\">
              <img src=\"";
        // line 13
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["site_logo_icon_url"] ?? null), "html", null, true));
        echo "\" alt=\"";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ((($context["site_name"] ?? null)) ? (($context["site_name"] ?? null)) : ("")), "html", null, true));
        echo "\" />
            </a>
          </div>

          ";
        // line 18
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "footer_top", array())) {
            // line 19
            echo "            <div class=\"site-footer__contact\">
              ";
            // line 20
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "footer_top", array()), "html", null, true));
            echo "
            </div>
          ";
        }
        // line 23
        echo "        </div>

        <div class=\"col-xs-12 col-sm-6\">
          ";
        // line 27
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "social_nav", array())) {
            // line 28
            echo "            <div class=\"social-media-nav\">
              ";
            // line 29
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "social_nav", array()), "html", null, true));
            echo "
            </div>
          ";
        }
        // line 32
        echo "        </div>
      </div>
    </div>

    ";
        // line 37
        echo "    <div class=\"site-footer__main\">
      <div class=\"row\">
        <div class=\"col-xs-12 col-md-3 col-lg-4\">
          ";
        // line 41
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "footer", array())) {
            // line 42
            echo "            <div class=\"\">
              ";
            // line 43
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "footer", array()), "html", null, true));
            echo "
            </div>
          ";
        }
        // line 46
        echo "        </div>

        <div class=\"hidden-xs hidden-sm col-md-9 col-lg-8\">
          ";
        // line 49
        if ($this->getAttribute(($context["page"] ?? null), "primary_nav", array())) {
            // line 50
            echo "            ";
            // line 51
            echo "            <div class=\"footer-main-nav\">
              ";
            // line 52
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "primary_nav", array()), "html", null, true));
            echo "
            </div>
          ";
        }
        // line 55
        echo "
          ";
        // line 56
        if ($this->getAttribute(($context["page"] ?? null), "special_nav", array())) {
            // line 57
            echo "            ";
            // line 58
            echo "            <div class=\"footer-main-nav\">
              ";
            // line 59
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "special_nav", array()), "html", null, true));
            echo "
            </div>
          ";
        }
        // line 62
        echo "
          ";
        // line 63
        if ($this->getAttribute(($context["page"] ?? null), "header_nav", array())) {
            // line 64
            echo "            ";
            // line 65
            echo "            <div class=\"footer-main-nav\">
              ";
            // line 66
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "header_nav", array()), "html", null, true));
            echo "
            </div>
          ";
        }
        // line 69
        echo "        </div>
      </div>
    </div>

    ";
        // line 74
        echo "    <div class=\"site-footer__bottom\">
      <div class=\"row\">
        <div class=\"hidden-xs col-sm-12 col-md-2 pull-right site-tours-wrapper\">
          ";
        // line 78
        echo "          <button type=\"button\" id=\"siteTours-start\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#siteTours\">
            <i class=\"fa fa-star fa-lg\"></i> ";
        // line 79
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Guided Tours")));
        echo "
          </button>
        </div>

        <div class=\"col-xs-12 col-md-10\">
          ";
        // line 85
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "footer_nav", array())) {
            // line 86
            echo "            <div class=\"footer-nav\">
              ";
            // line 87
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "footer_nav", array()), "html", null, true));
            echo "
            </div>
          ";
        }
        // line 90
        echo "
          ";
        // line 92
        echo "          <div class=\"site-footer__copyright\">
            ";
        // line 93
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Copyright &copy; @year", array("@year" => twig_date_format_filter($this->env, "now", "Y")))));
        echo "
            <a href=\"";
        // line 94
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["front_page"] ?? null), "html", null, true));
        echo "\">";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Urban Hipster Inc.")));
        echo "</a>.
            ";
        // line 95
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("All rights reserved.")));
        echo "
          </div>

          ";
        // line 99
        echo "          <div class=\"site-footer__acro\">
            ";
        // line 100
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Website design by")));
        echo " <a href=\"https://www.acromedia.com\" target=\"_blank\">";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Acro Media Inc.")));
        echo "</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>


";
        // line 110
        echo "<div class=\"modal fade\" id=\"siteTours\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"siteToursLabel\">
  <div class=\"modal-dialog\" role=\"document\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <button type=\"button\" id=\"headerCloseTours\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
        <h4 class=\"modal-title\" id=\"siteToursLabel\"><i class=\"fa fa-star fa-lg\"></i> ";
        // line 115
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Guided Tours")));
        echo "</h4>
      </div>
      <div class=\"modal-body\">
        <p>
          <strong>";
        // line 119
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Welcome to the Drupal Commerce 2 demo site!")));
        echo "</strong>
          <br>
          ";
        // line 121
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Select a guided feature tour below OR close the window and look around.")));
        echo "
        </p>

        <button type=\"button\" class=\"btn btn-primary\" id=\"homepageTour\">
          <i class=\"fa fa-home fa-lg\"></i> ";
        // line 125
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Homepage Features")));
        echo "
        </button>

        <button type=\"button\" class=\"btn btn-primary\" id=\"productPageTour\">
          <i class=\"fa fa-gift fa-lg\"></i> ";
        // line 129
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Product Page")));
        echo "
        </button>

        <button type=\"button\" class=\"btn btn-primary\" id=\"catalogFiltersTour\">
          <i class=\"fa fa-th-large fa-lg\"></i> ";
        // line 133
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Catalog & Filters")));
        echo "
        </button>

        <button type=\"button\" class=\"btn btn-primary\" id=\"solrSearchTour\">
          <i class=\"fa fa-search fa-lg\"></i> ";
        // line 137
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("SOLR Search")));
        echo "
        </button>

        <button type=\"button\" class=\"btn btn-primary\" id=\"quickCartTour\">
          <i class=\"fa fa-shopping-basket fa-lg\"></i> ";
        // line 141
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Quick Cart")));
        echo "
        </button>

        <button type=\"button\" class=\"btn btn-primary\" id=\"checkoutPhysicalTour\">
          <i class=\"fa fa-shopping-cart fa-lg\"></i> ";
        // line 145
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Checkout - Physical")));
        echo "
        </button>

        <button type=\"button\" class=\"btn btn-primary\" id=\"checkoutDigitalTour\">
          <i class=\"fa fa-cart-arrow-down fa-lg\"></i> ";
        // line 149
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Checkout - Digital")));
        echo "
        </button>

        ";
        // line 157
        echo "
        <button type=\"button\" class=\"btn btn-primary\" id=\"whyDrupalTour\">
          <i class=\"fa fa-drupal fa-lg\"></i> ";
        // line 159
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Why Drupal?")));
        echo "
        </button>

        <button type=\"button\" class=\"btn btn-primary\" id=\"whyOpenSourceTour\">
          <i class=\"fa fa-code fa-lg\"></i> ";
        // line 163
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Why Open Source?")));
        echo "
        </button>

        <div class=\"help-form text-left\">
          <h3>Need a Hand?</h3>
          Fill out the form to have one of our Drupal Commerce experts contact you.<br>
          <span class=\"small\">All fields marked with * are required.</span>

          <!--[if lte IE 8]>
          <script charset=\"utf-8\" type=\"text/javascript\" src=\"//js.hsforms.net/forms/v2-legacy.js\"></script>
          <![endif]-->
          <script charset=\"utf-8\" type=\"text/javascript\" src=\"//js.hsforms.net/forms/v2.js\"></script>
          <script>
            hbspt.forms.create({
              css: '',
              portalId: '1659229',
              formId: '4c37690f-26db-47d5-8e95-d9561e6f9594'
            });
          </script>
        </div>
      </div>
      <div class=\"modal-footer\">
        <div class=\"modal-credits\">
          ";
        // line 186
        echo t("Tours built by <a href=\"https://www.acromedia.com\" target=\"_blank\" title=\"Visit Acro Media's website\">Acro Media Inc.</a>", array());
        // line 189
        echo "        </div>

        <button type=\"button\" id=\"footerCloseTours\" class=\"btn btn-default\" data-dismiss=\"modal\">";
        // line 191
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Close")));
        echo "</button>
      </div>
    </div>
  </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "/themes/custom/commerce_2_demo/templates/pages/includes/site_footer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  363 => 191,  359 => 189,  357 => 186,  331 => 163,  324 => 159,  320 => 157,  314 => 149,  307 => 145,  300 => 141,  293 => 137,  286 => 133,  279 => 129,  272 => 125,  265 => 121,  260 => 119,  253 => 115,  246 => 110,  232 => 100,  229 => 99,  223 => 95,  217 => 94,  213 => 93,  210 => 92,  207 => 90,  201 => 87,  198 => 86,  195 => 85,  187 => 79,  184 => 78,  179 => 74,  173 => 69,  167 => 66,  164 => 65,  162 => 64,  160 => 63,  157 => 62,  151 => 59,  148 => 58,  146 => 57,  144 => 56,  141 => 55,  135 => 52,  132 => 51,  130 => 50,  128 => 49,  123 => 46,  117 => 43,  114 => 42,  111 => 41,  106 => 37,  100 => 32,  94 => 29,  91 => 28,  88 => 27,  83 => 23,  77 => 20,  74 => 19,  71 => 18,  62 => 13,  58 => 12,  55 => 11,  50 => 7,  45 => 3,  43 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/themes/custom/commerce_2_demo/templates/pages/includes/site_footer.html.twig", "/home/drupalcommerce/www/demo/web/themes/custom/commerce_2_demo/templates/pages/includes/site_footer.html.twig");
    }
}
