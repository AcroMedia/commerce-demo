<?php

/* /themes/custom/commerce_2_demo/templates/pages/includes/site_header.html.twig */
class __TwigTemplate_f1b5744a283de6831102ab65de5a93818d7ed48acd39d0067fe7e6a4826dc162 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("set" => 2, "if" => 5);
        $filters = array("t" => 15);
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('set', 'if'),
                array('t'),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 2
        $context["site_logo_url"] = ((($context["base_path"] ?? null) . ($context["directory"] ?? null)) . "/gfx/logo.svg");
        // line 3
        echo "
";
        // line 5
        if ($this->getAttribute(($context["page"] ?? null), "mobile_nav", array())) {
            // line 6
            echo "  ";
            if ($this->getAttribute(($context["page"] ?? null), "site_search", array())) {
                // line 7
                echo "    <div class=\"mobile-overlay mobile-search-overlay\">
      <div class=\"mobile-search-overlay__content mobile-overlay__content\">
        <a href=\"#\" class=\"mobile-search-overlay__close mobile-overlay__close\">
          <span class=\"fa fa-times\" aria-hidden=\"true\"></span>
        </a>

        <div class=\"mobile-search-form\">
          ";
                // line 14
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "site_search", array()), "html", null, true));
                echo "
          <a class=\"mobile-search-form__submit\" href=\"#\" title=\"";
                // line 15
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Search")));
                echo "\">
            <span class=\"fa fa-search\" aria-hidden=\"true\"></span>
          </a>
        </div>
      </div>
    </div>
  ";
            }
            // line 22
            echo "
  <div class=\"mobile-overlay mobile-nav-overlay\">
    <div class=\"mobile-nav-overlay__content mobile-overlay__content clearfix\">
      <header class=\"mobile-nav-overlay__header clearfix\" role=\"banner\">
        <a href=\"#\" class=\"mobile-nav-overlay__close mobile-overlay__close\">
          <span class=\"fa fa-times\" aria-hidden=\"true\"></span>
        </a>
      </header>

      <div class=\"mobile-nav\">
        ";
            // line 32
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "mobile_nav", array()), "html", null, true));
            echo "
      </div>
    </div>
  </div>
";
        }
        // line 38
        echo "
<header class=\"site-header\">
  ";
        // line 41
        echo "  <div class=\"site-header__top-bar\">
    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-md-12 col-lg-6 site-header__top-bar--left\">
          ";
        // line 45
        if ($this->getAttribute(($context["page"] ?? null), "header_promo", array())) {
            // line 46
            echo "            ";
            // line 47
            echo "            <div class=\"site-header__promo\">
              ";
            // line 48
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "header_promo", array()), "html", null, true));
            echo "
            </div>
          ";
        }
        // line 51
        echo "        </div>

        <div class=\"hidden-xs col-md-12 col-lg-6 site-header__top-bar--right\">
          ";
        // line 54
        if ($this->getAttribute(($context["page"] ?? null), "header_nav", array())) {
            // line 55
            echo "            ";
            // line 56
            echo "            <div class=\"site-header-nav\">
              ";
            // line 57
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "header_nav", array()), "html", null, true));
            echo "
            </div>
          ";
        }
        // line 60
        echo "
          ";
        // line 61
        if ($this->getAttribute(($context["page"] ?? null), "language_select", array())) {
            // line 62
            echo "            ";
            // line 63
            echo "            <div class=\"site-header__language-select\">
              ";
            // line 64
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "language_select", array()), "html", null, true));
            echo "
            </div>
          ";
        }
        // line 67
        echo "        </div>
      </div>
    </div>
  </div>

  ";
        // line 73
        echo "  <div class=\"site-header__top container\">
    <div class=\"row\">
      <div class=\"col-xs-8 col-sm-5 col-md-5\">
        ";
        // line 77
        echo "        <div class=\"site-header__logo\">
          <a href=\"";
        // line 78
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["front_page"] ?? null), "html", null, true));
        echo "\">
            <img src=\"";
        // line 79
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["site_logo_url"] ?? null), "html", null, true));
        echo "\" alt=\"";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ((($context["site_name"] ?? null)) ? (($context["site_name"] ?? null)) : ("")), "html", null, true));
        echo "\" />
          </a>
        </div>
      </div>

      <div class=\"col-xs-4 col-sm-7 col-md-7 site-header__main\">
        <div class=\"hidden-xs site-header__main-left\">
          ";
        // line 87
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "header", array())) {
            // line 88
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "header", array()), "html", null, true));
            echo "
          ";
        }
        // line 90
        echo "        </div>

        <div class=\"hidden-xs site-header__main-right\">
          ";
        // line 94
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "header_right", array())) {
            // line 95
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "header_right", array()), "html", null, true));
            echo "
          ";
        }
        // line 97
        echo "        </div>

        ";
        // line 100
        echo "        ";
        if ($this->getAttribute(($context["page"] ?? null), "mobile_nav", array())) {
            // line 101
            echo "          <div class=\"mobile-control-nav visible-xs-block\">
            <ul class=\"menu clearfix\">
              <li class=\"menu__item menu__item--search\">
                <a href=\"#\" class=\"menu__link\" title=\"";
            // line 104
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Search")));
            echo "\">
                  <span aria-hidden=\"true\" class=\"fa fa-search\"></span>
                </a>
              </li>
              <li class=\"menu__item menu__item--menu\">
                <a href=\"#\" class=\"menu__link\" title=\"";
            // line 109
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Menu")));
            echo "\">
                  <span aria-hidden=\"true\" class=\"fa fa-bars\"></span>
                </a>
              </li>
            </ul>
          </div>
        ";
        }
        // line 116
        echo "        ";
        // line 117
        echo "
        ";
        // line 119
        echo "        ";
        if ($this->getAttribute(($context["page"] ?? null), "site_search", array())) {
            // line 120
            echo "          <div class=\"hidden-xs site-header__search\">
            ";
            // line 121
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "site_search", array()), "html", null, true));
            echo "
          </div>
        ";
        }
        // line 124
        echo "      </div>
    </div>
  </div>

  ";
        // line 129
        echo "  <div class=\"site-header__bottom\">
    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-md-12\">
          ";
        // line 133
        if ($this->getAttribute(($context["page"] ?? null), "primary_nav", array())) {
            // line 134
            echo "           ";
            // line 135
            echo "            <div class=\"primary-nav hidden-xs\">
              ";
            // line 136
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "primary_nav", array()), "html", null, true));
            echo "
            </div>
          ";
        }
        // line 139
        echo "        </div>
      </div>
    </div>
  </div>
</header>
";
    }

    public function getTemplateName()
    {
        return "/themes/custom/commerce_2_demo/templates/pages/includes/site_header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  279 => 139,  273 => 136,  270 => 135,  268 => 134,  266 => 133,  260 => 129,  254 => 124,  248 => 121,  245 => 120,  242 => 119,  239 => 117,  237 => 116,  227 => 109,  219 => 104,  214 => 101,  211 => 100,  207 => 97,  201 => 95,  198 => 94,  193 => 90,  187 => 88,  184 => 87,  172 => 79,  168 => 78,  165 => 77,  160 => 73,  153 => 67,  147 => 64,  144 => 63,  142 => 62,  140 => 61,  137 => 60,  131 => 57,  128 => 56,  126 => 55,  124 => 54,  119 => 51,  113 => 48,  110 => 47,  108 => 46,  106 => 45,  100 => 41,  96 => 38,  88 => 32,  76 => 22,  66 => 15,  62 => 14,  53 => 7,  50 => 6,  48 => 5,  45 => 3,  43 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/themes/custom/commerce_2_demo/templates/pages/includes/site_header.html.twig", "/home/drupalcommerce/www/demo/web/themes/custom/commerce_2_demo/templates/pages/includes/site_header.html.twig");
    }
}
