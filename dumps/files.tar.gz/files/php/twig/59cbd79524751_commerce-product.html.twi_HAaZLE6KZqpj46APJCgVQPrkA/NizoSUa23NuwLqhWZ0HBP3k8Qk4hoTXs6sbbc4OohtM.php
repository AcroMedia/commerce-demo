<?php

/* themes/custom/commerce_2_demo/templates/commerce/commerce-product.html.twig */
class __TwigTemplate_1f39d97910290989d4998a74e290f2c30dd177762618edd1a5aa52d2813c7de0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("if" => 22);
        $filters = array("t" => 49, "trim" => 95, "render" => 95);
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('if'),
                array('t', 'trim', 'render'),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 22
        if ((($context["view_mode"] ?? null) == "teaser")) {
            // line 23
            echo "  ";
            // line 24
            echo "  <a href=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["product_url"] ?? null), "html", null, true));
            echo "\" class=\"product product--teaser\" aria-label=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute(($context["product_entity"] ?? null), "title", array()), "value", array()), "html", null, true));
            echo "\">
    <div class=\"product--thumbnail\">
      ";
            // line 26
            if (($context["product_image_thumb_url"] ?? null)) {
                // line 27
                echo "        <img src=\"";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["product_image_thumb_url"] ?? null), "html", null, true));
                echo "\" alt=\"";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute(($context["product_entity"] ?? null), "title", array()), "value", array()), "html", null, true));
                echo "\" />
      ";
            } else {
                // line 29
                echo "        <img src=\"";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, (($context["base_path"] ?? null) . ($context["directory"] ?? null)), "html", null, true));
                echo "/gfx/logo-icon.svg\" class=\"no-product-thumbnail\" alt=\"";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute(($context["product_entity"] ?? null), "title", array()), "value", array()), "html", null, true));
                echo "\" />
      ";
            }
            // line 31
            echo "    </div>

    ";
            // line 33
            if ($this->getAttribute($this->getAttribute($this->getAttribute(($context["product"] ?? null), "variation_field_original_price", array()), 0, array(), "array"), "#markup", array(), "array")) {
                // line 34
                echo "      ";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["product"] ?? null), "variation_field_original_price", array()), "html", null, true));
                echo "
    ";
            }
            // line 36
            echo "    ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["product"] ?? null), "variation_price", array()), "html", null, true));
            echo "
    ";
            // line 37
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["product"] ?? null), "title", array()), "html", null, true));
            echo "
    ";
            // line 38
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["product"] ?? null), "field_brand", array()), "html", null, true));
            echo "
    ";
            // line 39
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["product"] ?? null), "field_artist", array()), "html", null, true));
            echo "
  </a>

";
        } else {
            // line 43
            echo "
  ";
            // line 45
            echo "  <article";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["attributes"] ?? null), "html", null, true));
            echo " class=\"product product--full\">
    <div class=\"row\">
      <div class=\"col-xs-12 back-and-share\">
        ";
            // line 49
            echo "        <a href=\"/products\" class=\"back-to-products\">";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Back to Products")));
            echo "</a>

        ";
            // line 52
            echo "        <div class=\"sharethis-inline-share-buttons\"></div>
      </div>
    </div>

    <div class=\"row\">
      ";
            // line 57
            if (($context["product_image_full_url"] ?? null)) {
                // line 58
                echo "        ";
                // line 59
                echo "        <div class=\"col-sm-12 col-md-6\">
          <div class=\"product--images\">
            ";
                // line 61
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["product"] ?? null), "variation_field_image", array()), "html", null, true));
                echo "
          </div>
        </div>
        ";
                // line 65
                echo "        <div class=\"col-sm-12 col-md-6\">
          <div class=\"product--intro\">
      ";
            } else {
                // line 68
                echo "        ";
                // line 69
                echo "        <div class=\"col-sm-12\">
          <div class=\"product--intro product--intro__full-width\">
      ";
            }
            // line 72
            echo "
            ";
            // line 73
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["product"] ?? null), "field_brand", array()), "html", null, true));
            echo "
            ";
            // line 74
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["product"] ?? null), "field_artist", array()), "html", null, true));
            echo "
            <h1 class=\"page-title\">";
            // line 75
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute(($context["product_entity"] ?? null), "title", array()), "value", array()), "html", null, true));
            echo "</h1>
            ";
            // line 76
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["product"] ?? null), "variation_price", array()), "html", null, true));
            echo "
            ";
            // line 77
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["product"] ?? null), "field_short_description", array()), "html", null, true));
            echo "

            ";
            // line 80
            echo "            ";
            if (($this->getAttribute(($context["product_entity"] ?? null), "bundle", array()) == "audio_download")) {
                // line 81
                echo "              <strong>";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Format:")));
                echo "</strong> ";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Digital")));
                echo "
            ";
            }
            // line 83
            echo "
            ";
            // line 84
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["product"] ?? null), "variations", array()), "html", null, true));
            echo "
          </div>
      </div>
    </div>

    <div class=\"row\">
      <div class=\"col-sm-12\">
        ";
            // line 92
            echo "        <div class=\"additional-details\">
          ";
            // line 94
            echo "          <ul id=\"product-tabs\" class=\"nav nav-tabs\" role=\"tablist\">
            ";
            // line 95
            if ( !twig_test_empty(twig_trim_filter($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->getAttribute(($context["product"] ?? null), "body", array()))))) {
                // line 96
                echo "              <li role=\"presentation\">
                <a href=\"#description\" aria-controls=\"description\" role=\"tab\" data-toggle=\"tab\">
                  ";
                // line 98
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Description")));
                echo "
                </a>
              </li>
            ";
            }
            // line 102
            echo "
            ";
            // line 103
            if ( !twig_test_empty(twig_trim_filter($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->getAttribute(($context["product"] ?? null), "field_specifications", array()))))) {
                // line 104
                echo "              <li role=\"presentation\">
                <a href=\"#specifications\" aria-controls=\"specifications\" role=\"tab\" data-toggle=\"tab\">
                  ";
                // line 106
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Specifications")));
                echo "
                </a>
              </li>
            ";
            }
            // line 110
            echo "
            <li role=\"presentation\">
              <a href=\"#reviews\" aria-controls=\"reviews\" role=\"tab\" data-toggle=\"tab\">
                ";
            // line 113
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Reviews")));
            echo " <span class=\"badge\">";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["product_reviews_count"] ?? null), "html", null, true));
            echo "</span>
              </a>
            </li>
          </ul>

          ";
            // line 119
            echo "          <div class=\"tab-content\">
            ";
            // line 120
            if ( !twig_test_empty(twig_trim_filter($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->getAttribute(($context["product"] ?? null), "body", array()))))) {
                // line 121
                echo "              <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"description\">
                ";
                // line 122
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["product"] ?? null), "body", array()), "html", null, true));
                echo "
              </div>
            ";
            }
            // line 125
            echo "
            ";
            // line 126
            if ( !twig_test_empty(twig_trim_filter($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->getAttribute(($context["product"] ?? null), "field_specifications", array()))))) {
                // line 127
                echo "              <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"specifications\">
                ";
                // line 128
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["product"] ?? null), "field_specifications", array()), "html", null, true));
                echo "
              </div>
            ";
            }
            // line 131
            echo "
            <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"reviews\">
              <input type=\"checkbox\" id=\"submit-review\">
              <label class=\"btn btn-primary btn-sm\" for=\"submit-review\">Submit a Review</label>
              <div class=\"review-rating\">
                <p>Overall Rating</p>
                <span class=\"";
            // line 137
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar((((($context["rating_average"] ?? null) >= 1)) ? ("filled") : (""))));
            echo "\"></span>
                <span class=\"half ";
            // line 138
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar((((($context["rating_average"] ?? null) >= 1.5)) ? ("filled") : (""))));
            echo "\"></span>
                <span class=\"";
            // line 139
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar((((($context["rating_average"] ?? null) >= 2)) ? ("filled") : (""))));
            echo "\"></span>
                <span class=\"half ";
            // line 140
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar((((($context["rating_average"] ?? null) >= 2.5)) ? ("filled") : (""))));
            echo "\"></span>
                <span class=\"";
            // line 141
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar((((($context["rating_average"] ?? null) >= 3)) ? ("filled") : (""))));
            echo "\"></span>
                <span class=\"half ";
            // line 142
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar((((($context["rating_average"] ?? null) >= 3.5)) ? ("filled") : (""))));
            echo "\"></span>
                <span class=\"";
            // line 143
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar((((($context["rating_average"] ?? null) >= 4)) ? ("filled") : (""))));
            echo "\"></span>
                <span class=\"half ";
            // line 144
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar((((($context["rating_average"] ?? null) >= 4.5)) ? ("filled") : (""))));
            echo "\"></span>
                <span class=\"";
            // line 145
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar((((($context["rating_average"] ?? null) == 5)) ? ("filled") : (""))));
            echo "\"></span>
              </div>
              ";
            // line 147
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["product"] ?? null), "field_product_reviews", array()), "html", null, true));
            echo "
            </div>
          </div>
        </div>
        ";
            // line 152
            echo "      </div>
    </div>

    ";
            // line 156
            echo "    ";
            if ( !twig_test_empty(twig_trim_filter($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->getAttribute(($context["product"] ?? null), "field_recommended_products", array()))))) {
                // line 157
                echo "      <div class=\"row\">
        <div class=\"col-sm-12\">
          <div class=\"recommended-products\">
            ";
                // line 160
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["product"] ?? null), "field_recommended_products", array()), "html", null, true));
                echo "
          </div>
        </div>
      </div>
    ";
            }
            // line 165
            echo "  </article>

";
        }
    }

    public function getTemplateName()
    {
        return "themes/custom/commerce_2_demo/templates/commerce/commerce-product.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  353 => 165,  345 => 160,  340 => 157,  337 => 156,  332 => 152,  325 => 147,  320 => 145,  316 => 144,  312 => 143,  308 => 142,  304 => 141,  300 => 140,  296 => 139,  292 => 138,  288 => 137,  280 => 131,  274 => 128,  271 => 127,  269 => 126,  266 => 125,  260 => 122,  257 => 121,  255 => 120,  252 => 119,  242 => 113,  237 => 110,  230 => 106,  226 => 104,  224 => 103,  221 => 102,  214 => 98,  210 => 96,  208 => 95,  205 => 94,  202 => 92,  192 => 84,  189 => 83,  181 => 81,  178 => 80,  173 => 77,  169 => 76,  165 => 75,  161 => 74,  157 => 73,  154 => 72,  149 => 69,  147 => 68,  142 => 65,  136 => 61,  132 => 59,  130 => 58,  128 => 57,  121 => 52,  115 => 49,  108 => 45,  105 => 43,  98 => 39,  94 => 38,  90 => 37,  85 => 36,  79 => 34,  77 => 33,  73 => 31,  65 => 29,  57 => 27,  55 => 26,  47 => 24,  45 => 23,  43 => 22,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/commerce_2_demo/templates/commerce/commerce-product.html.twig", "/home/drupalcommerce/www/demo/web/themes/custom/commerce_2_demo/templates/commerce/commerce-product.html.twig");
    }
}
