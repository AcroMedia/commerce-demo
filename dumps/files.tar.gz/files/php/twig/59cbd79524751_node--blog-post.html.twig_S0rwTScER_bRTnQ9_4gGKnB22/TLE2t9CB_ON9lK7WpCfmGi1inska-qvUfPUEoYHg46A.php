<?php

/* themes/custom/commerce_2_demo/templates/nodes/node--blog-post.html.twig */
class __TwigTemplate_7bc5fc0cc823c92e15911726c76ea0e21c6b14411e412bd80c034069413f0110 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("set" => 17, "if" => 27, "for" => 69);
        $filters = array("clean_class" => 19, "t" => 54, "striptags" => 59, "render" => 59, "length" => 60, "slice" => 60);
        $functions = array("path" => 71);

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('set', 'if', 'for'),
                array('clean_class', 't', 'striptags', 'render', 'length', 'slice'),
                array('path')
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 17
        $context["classes"] = array(0 => "node", 1 => ("node--type-" . \Drupal\Component\Utility\Html::getClass($this->getAttribute(        // line 19
($context["node"] ?? null), "bundle", array()))), 2 => (($this->getAttribute(        // line 20
($context["node"] ?? null), "isPromoted", array(), "method")) ? ("node--promoted") : ("")), 3 => (($this->getAttribute(        // line 21
($context["node"] ?? null), "isSticky", array(), "method")) ? ("node--sticky") : ("")), 4 => (( !$this->getAttribute(        // line 22
($context["node"] ?? null), "isPublished", array(), "method")) ? ("node--unpublished") : ("")), 5 => ((        // line 23
($context["view_mode"] ?? null)) ? (("node--view-mode-" . \Drupal\Component\Utility\Html::getClass(($context["view_mode"] ?? null)))) : ("")), 6 => "clearfix");
        // line 27
        if ((($context["view_mode"] ?? null) == "teaser")) {
            // line 28
            echo "
  <div class=\"blog-listing-item blog-listing-item--teaser\">
    <div class=\"blog-listing-item__image\">
      <a href=\"";
            // line 31
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["url"] ?? null), "html", null, true));
            echo "\"><img src=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["blog_image_url"] ?? null), "html", null, true));
            echo "\" alt=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_blog_image", array()), "alt", array()), "html", null, true));
            echo "\" /></a>
    </div>
    <h3 class=\"blog-listing-item__title\">
      <a href=\"";
            // line 34
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["url"] ?? null), "html", null, true));
            echo "\">";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["label"] ?? null), "html", null, true));
            echo "</a>
    </h3>
  </div>

";
        } elseif ((        // line 38
($context["view_mode"] ?? null) == "listing")) {
            // line 39
            echo "
  <div class=\"blog-listing-item\">
    <div class=\"blog-listing-item__image\">
      <a href=\"";
            // line 42
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["url"] ?? null), "html", null, true));
            echo "\"><img src=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["blog_image_url"] ?? null), "html", null, true));
            echo "\" alt=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_blog_image", array()), "alt", array()), "html", null, true));
            echo "\" /></a>
    </div>
    <h3 class=\"blog-listing-item__title\">
      <a href=\"";
            // line 45
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["url"] ?? null), "html", null, true));
            echo "\">";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["label"] ?? null), "html", null, true));
            echo "</a>
    </h3>
    <div class=\"blog-post-meta\">
      <div class=\"blog-post-meta__date\">
        ";
            // line 49
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["blog_post_date"] ?? null), "html", null, true));
            echo "
      </div>
      ";
            // line 51
            if (($context["blog_author_name"] ?? null)) {
                // line 52
                echo "        <i>|</i>
         <div class=\"blog-post-meta__author\">
          ";
                // line 54
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("By")));
                echo " <a href=\"";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["base_path"] ?? null), "html", null, true));
                echo "blog/author/";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["blog_author_id"] ?? null), "html", null, true));
                echo "\">";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["blog_author_name"] ?? null), "html", null, true));
                echo "</a>
        </div>
      ";
            }
            // line 57
            echo "    </div>
    <div class=\"blog-listing-item__body\">
      ";
            // line 59
            $context["teaser_text"] = strip_tags($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->getAttribute(($context["content"] ?? null), "body", array())));
            // line 60
            echo "      ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, (((twig_length_filter($this->env, ($context["teaser_text"] ?? null)) > 300)) ? ((twig_slice($this->env, ($context["teaser_text"] ?? null), 0, 300) . "...")) : (($context["teaser_text"] ?? null))), "html", null, true));
            echo "
    </div>
    <div class=\"blog-listing-item__footer clearfix\">
      <a class=\"btn btn-primary\" href=\"";
            // line 63
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["url"] ?? null), "html", null, true));
            echo "\">";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Read More")));
            echo "</a>

      ";
            // line 65
            if ($this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_blog_category", array()), "target_id", array())) {
                // line 66
                echo "        <div class=\"blog-listing-item__tags blog-post-tags\">
          <span class=\"blog-post-tags--label\">";
                // line 67
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Posted in")));
                echo "</span>
          <ul class=\"blog-post-tags__list clearfix\">
            ";
                // line 69
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["node"] ?? null), "field_blog_category", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
                    // line 70
                    echo "              <li>
                <a href=\"";
                    // line 71
                    echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\Core\Template\TwigExtension')->getPath("entity.taxonomy_term.canonical", array("taxonomy_term" => $this->getAttribute($this->getAttribute($this->getAttribute($context["category"], "entity", array()), "tid", array()), "value", array()))), "html", null, true));
                    echo "\">";
                    echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["category"], "entity", array()), "name", array()), "value", array()), "html", null, true));
                    echo "</a>
              </li>
            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 74
                echo "          </ul>
        </div>
      ";
            }
            // line 77
            echo "    </div>
  </div>

";
        } else {
            // line 81
            echo "
  <article";
            // line 82
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["attributes"] ?? null), "addClass", array(0 => ($context["classes"] ?? null)), "method"), "html", null, true));
            echo ">
    ";
            // line 83
            if (($context["blog_image_url"] ?? null)) {
                // line 84
                echo "      <div class=\"blog-post-image\">
        <img src=\"";
                // line 85
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["blog_image_url"] ?? null), "html", null, true));
                echo "\" alt=\"";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_blog_image", array()), "alt", array()), "html", null, true));
                echo "\" />
      </div>
    ";
            }
            // line 88
            echo "
    <div class=\"social-media-sharing-nav\">
      <ul class=\"social-media-sharing-menu clearfix\">
        <li class=\"social-media-sharing-menu__item\">
          <a class=\"social-media-sharing-menu__link social-media-sharing-menu__link--facebook\" href=\"https://facebook.com/sharer/sharer.php?u=";
            // line 92
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["absolute_encoded_path"] ?? null), "html", null, true));
            echo "\" target=\"_blank\" aria-label=\"\" title=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Share on Facebook")));
            echo "\"><i class=\"fa fa-facebook\" aria-hidden=\"true\"></i></a>
        </li>
        <li class=\"social-media-sharing-menu__item\">
          <a class=\"social-media-sharing-menu__link social-media-sharing-menu__link--twitter\" href=\"https://twitter.com/intent/tweet/?text=";
            // line 95
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["encoded_title"] ?? null), "html", null, true));
            echo "&amp;url=";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["absolute_encoded_path"] ?? null), "html", null, true));
            echo "\" target=\"_blank\" aria-label=\"\" title=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Share on Twitter")));
            echo "\"><i class=\"fa fa-twitter\" aria-hidden=\"true\"></i></a>
        </li>
        <li class=\"social-media-sharing-menu__item\">
          <a class=\"social-media-sharing-menu__link social-media-sharing-menu__link--google-plus\" href=\"https://plus.google.com/share?url=";
            // line 98
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["absolute_encoded_path"] ?? null), "html", null, true));
            echo "\" target=\"_blank\" aria-label=\"\" title=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Share on Google+")));
            echo "\"><i class=\"fa fa-google-plus\" aria-hidden=\"true\"></i></a>
        </li>
        <li class=\"social-media-sharing-menu__item\">
          <a class=\"social-media-sharing-menu__link social-media-sharing-menu__link--linkedin\" href=\"https://www.linkedin.com/shareArticle?mini=true&amp;url=";
            // line 101
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["absolute_encoded_path"] ?? null), "html", null, true));
            echo "&amp;title=";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["encoded_title"] ?? null), "html", null, true));
            echo "&amp;summary=";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["encoded_title"] ?? null), "html", null, true));
            echo "&amp;source=";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["absolute_encoded_path"] ?? null), "html", null, true));
            echo "\" target=\"_blank\" aria-label=\"\" title=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Share on LinkedIn")));
            echo "\"><i class=\"fa fa-linkedin\" aria-hidden=\"true\"></i></a>
        </li>
      </ul>
    </div>

    ";
            // line 106
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["title_prefix"] ?? null), "html", null, true));
            echo "
    <h1 ";
            // line 107
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["title_attributes"] ?? null), "addClass", array(0 => "page-title--blog-post"), "method"), "html", null, true));
            echo ">";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["label"] ?? null), "html", null, true));
            echo "</h1>
    ";
            // line 108
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["title_suffix"] ?? null), "html", null, true));
            echo "

    <div class=\"blog-post-meta blog-post-meta-node\">
      ";
            // line 111
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["blog_post_date"] ?? null), "html", null, true));
            echo "
      ";
            // line 112
            if (($context["blog_author_name"] ?? null)) {
                // line 113
                echo "        <i>|</i>
        ";
                // line 114
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("By")));
                echo " <a href=\"";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["base_path"] ?? null), "html", null, true));
                echo "blog/author/";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["blog_author_id"] ?? null), "html", null, true));
                echo "\">";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["blog_author_name"] ?? null), "html", null, true));
                echo "</a>
      ";
            }
            // line 116
            echo "    </div>

    <div";
            // line 118
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["content_attributes"] ?? null), "html", null, true));
            echo ">
      ";
            // line 119
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["content"] ?? null), "body", array()), "html", null, true));
            echo "
    </div>

    ";
            // line 122
            if ($this->getAttribute($this->getAttribute(($context["node"] ?? null), "field_blog_category", array()), "target_id", array())) {
                // line 123
                echo "      <div class=\"blog-post-footer\">
        <div class=\"blog-post-tags\">
          ";
                // line 125
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Posted in")));
                echo "
          <ul class=\"blog-post-tags__list clearfix\">
            ";
                // line 127
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["node"] ?? null), "field_blog_category", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
                    // line 128
                    echo "              <li>
                <a href=\"";
                    // line 129
                    echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\Core\Template\TwigExtension')->getPath("entity.taxonomy_term.canonical", array("taxonomy_term" => $this->getAttribute($this->getAttribute($this->getAttribute($context["category"], "entity", array()), "tid", array()), "value", array()))), "html", null, true));
                    echo "\">";
                    echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["category"], "entity", array()), "name", array()), "value", array()), "html", null, true));
                    echo "</a>
              </li>
            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 132
                echo "          </ul>
        </div>
      </div>
    ";
            }
            // line 136
            echo "
    ";
            // line 137
            if ($this->getAttribute(($context["content"] ?? null), "field_blog_comments", array())) {
                // line 138
                echo "      <div class=\"blog-post-comments\">
        ";
                // line 139
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["content"] ?? null), "field_blog_comments", array()), "html", null, true));
                echo "
      </div>
    ";
            }
            // line 142
            echo "  </article>

";
        }
    }

    public function getTemplateName()
    {
        return "themes/custom/commerce_2_demo/templates/nodes/node--blog-post.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  351 => 142,  345 => 139,  342 => 138,  340 => 137,  337 => 136,  331 => 132,  320 => 129,  317 => 128,  313 => 127,  308 => 125,  304 => 123,  302 => 122,  296 => 119,  292 => 118,  288 => 116,  277 => 114,  274 => 113,  272 => 112,  268 => 111,  262 => 108,  256 => 107,  252 => 106,  236 => 101,  228 => 98,  218 => 95,  210 => 92,  204 => 88,  196 => 85,  193 => 84,  191 => 83,  187 => 82,  184 => 81,  178 => 77,  173 => 74,  162 => 71,  159 => 70,  155 => 69,  150 => 67,  147 => 66,  145 => 65,  138 => 63,  131 => 60,  129 => 59,  125 => 57,  113 => 54,  109 => 52,  107 => 51,  102 => 49,  93 => 45,  83 => 42,  78 => 39,  76 => 38,  67 => 34,  57 => 31,  52 => 28,  50 => 27,  48 => 23,  47 => 22,  46 => 21,  45 => 20,  44 => 19,  43 => 17,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/commerce_2_demo/templates/nodes/node--blog-post.html.twig", "/home/drupalcommerce/www/demo/web/themes/custom/commerce_2_demo/templates/nodes/node--blog-post.html.twig");
    }
}
