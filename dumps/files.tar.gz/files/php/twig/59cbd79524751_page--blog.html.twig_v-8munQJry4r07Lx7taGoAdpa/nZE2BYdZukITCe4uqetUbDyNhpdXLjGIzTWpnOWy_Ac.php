<?php

/* themes/custom/commerce_2_demo/templates/pages/page--blog.html.twig */
class __TwigTemplate_f421df47f56582ea27a572e215f7409b5837a73e866f475c736e8bc280e30711 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("set" => 53, "include" => 59, "if" => 65);
        $filters = array();
        $functions = array("render_var" => 53);

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('set', 'include', 'if'),
                array(),
                array('render_var')
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 53
        $context["page_sidebar_rendered"] = $this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->getAttribute(($context["page"] ?? null), "blog_sidebar", array()));
        // line 55
        $context["row_class"] = ((($context["page_sidebar_rendered"] ?? null)) ? ("row-eq-height") : (""));
        // line 56
        $context["col_class"] = ((($context["page_sidebar_rendered"] ?? null)) ? ("col-sm-8 col-md-9") : ("col-md-12"));
        // line 57
        echo "
";
        // line 59
        $this->loadTemplate(((($context["base_path"] ?? null) . ($context["directory"] ?? null)) . "/templates/pages/includes/site_header.html.twig"), "themes/custom/commerce_2_demo/templates/pages/page--blog.html.twig", 59)->display($context);
        // line 61
        echo "
";
        // line 63
        echo "<div class=\"site-content blog-content\">
  <div class=\"container\">
    ";
        // line 65
        if (($context["title"] ?? null)) {
            // line 66
            echo "      <h3>";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["title"] ?? null), "html", null, true));
            echo "</h3>
    ";
        }
        // line 68
        echo "
    <div class=\"row ";
        // line 69
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["row_class"] ?? null), "html", null, true));
        echo "\">
      <div class=\"";
        // line 70
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["col_class"] ?? null), "html", null, true));
        echo "\">
        <main class=\"content__main-content blog_content__main-content clearfix\" role=\"main\">
          <div class=\"visually-hidden\"><a id=\"main-content\" tabindex=\"-1\"></a></div>
          ";
        // line 73
        if ($this->getAttribute(($context["page"] ?? null), "highlighted", array())) {
            // line 74
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "highlighted", array()), "html", null, true));
            echo "
          ";
        }
        // line 76
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "above_content", array())) {
            // line 77
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "above_content", array()), "html", null, true));
            echo "
          ";
        }
        // line 79
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "content", array())) {
            // line 80
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "content", array()), "html", null, true));
            echo "
          ";
        }
        // line 82
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "below_content", array())) {
            // line 83
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "below_content", array()), "html", null, true));
            echo "
          ";
        }
        // line 85
        echo "        </main>
      </div>

      ";
        // line 88
        if (($context["page_sidebar_rendered"] ?? null)) {
            // line 89
            echo "        <div class=\"col-sm-4 col-md-3\">
          <aside class=\"site-sidebar site-sidebar--blog\" role=\"complementary\">
            ";
            // line 91
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "blog_sidebar", array()), "html", null, true));
            echo "
          </aside>
        </div>
      ";
        }
        // line 95
        echo "    </div>
  </div>
</div>
";
        // line 99
        echo "
";
        // line 101
        $this->loadTemplate(((($context["base_path"] ?? null) . ($context["directory"] ?? null)) . "/templates/pages/includes/site_footer.html.twig"), "themes/custom/commerce_2_demo/templates/pages/page--blog.html.twig", 101)->display($context);
    }

    public function getTemplateName()
    {
        return "themes/custom/commerce_2_demo/templates/pages/page--blog.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  143 => 101,  140 => 99,  135 => 95,  128 => 91,  124 => 89,  122 => 88,  117 => 85,  111 => 83,  108 => 82,  102 => 80,  99 => 79,  93 => 77,  90 => 76,  84 => 74,  82 => 73,  76 => 70,  72 => 69,  69 => 68,  63 => 66,  61 => 65,  57 => 63,  54 => 61,  52 => 59,  49 => 57,  47 => 56,  45 => 55,  43 => 53,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/commerce_2_demo/templates/pages/page--blog.html.twig", "/home/drupalcommerce/www/demo/web/themes/custom/commerce_2_demo/templates/pages/page--blog.html.twig");
    }
}
