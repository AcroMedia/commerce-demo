<?php

/* themes/custom/commerce_2_demo/templates/pages/page--front.html.twig */
class __TwigTemplate_6d24743a78b283458b00cadff6ac17bcd7a2fea59264e8d2d3a0c2a8875846fb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("include" => 13, "if" => 16);
        $filters = array("without" => 34);
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('include', 'if'),
                array('without'),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 13
        $this->loadTemplate(((($context["base_path"] ?? null) . ($context["directory"] ?? null)) . "/templates/pages/includes/site_header.html.twig"), "themes/custom/commerce_2_demo/templates/pages/page--front.html.twig", 13)->display($context);
        // line 15
        echo "
";
        // line 16
        if (($context["homepage_carousel_view"] ?? null)) {
            // line 17
            echo "  ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["homepage_carousel_view"] ?? null), "html", null, true));
            echo "
";
        }
        // line 19
        echo "
";
        // line 21
        echo "<div class=\"site-content\">
  <div class=\"container\">
    <div class=\"row\">
      <div class=\"col-md-12\">
        <main class=\"content__main-content clearfix\" role=\"main\">
          <div class=\"visually-hidden\"><a id=\"main-content\" tabindex=\"-1\"></a></div>
          ";
        // line 27
        if ($this->getAttribute(($context["page"] ?? null), "highlighted", array())) {
            // line 28
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "highlighted", array()), "html", null, true));
            echo "
          ";
        }
        // line 30
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "above_content", array())) {
            // line 31
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "above_content", array()), "html", null, true));
            echo "
          ";
        }
        // line 33
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "content", array())) {
            // line 34
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_without($this->getAttribute(($context["page"] ?? null), "content", array()), "system_main"), "html", null, true));
            echo "
          ";
        }
        // line 36
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "below_content", array())) {
            // line 37
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "below_content", array()), "html", null, true));
            echo "
          ";
        }
        // line 39
        echo "        </main>
      </div>
    </div>
  </div>
</div>
";
        // line 45
        echo "
";
        // line 47
        $this->loadTemplate(((($context["base_path"] ?? null) . ($context["directory"] ?? null)) . "/templates/pages/includes/site_footer.html.twig"), "themes/custom/commerce_2_demo/templates/pages/page--front.html.twig", 47)->display($context);
    }

    public function getTemplateName()
    {
        return "themes/custom/commerce_2_demo/templates/pages/page--front.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 47,  109 => 45,  102 => 39,  96 => 37,  93 => 36,  87 => 34,  84 => 33,  78 => 31,  75 => 30,  69 => 28,  67 => 27,  59 => 21,  56 => 19,  50 => 17,  48 => 16,  45 => 15,  43 => 13,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/commerce_2_demo/templates/pages/page--front.html.twig", "/home/drupalcommerce/www/demo/web/themes/custom/commerce_2_demo/templates/pages/page--front.html.twig");
    }
}
