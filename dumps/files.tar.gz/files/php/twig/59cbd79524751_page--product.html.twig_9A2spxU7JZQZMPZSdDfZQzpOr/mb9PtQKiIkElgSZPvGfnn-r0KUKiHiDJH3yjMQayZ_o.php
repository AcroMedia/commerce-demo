<?php

/* themes/custom/commerce_2_demo/templates/pages/page--product.html.twig */
class __TwigTemplate_77f1e08236e4b329aa103ea893a11715eda3aa85fb8bebaef11c885652affb09 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("include" => 50, "if" => 60);
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('include', 'if'),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 48
        echo "
";
        // line 50
        $this->loadTemplate(((($context["base_path"] ?? null) . ($context["directory"] ?? null)) . "/templates/pages/includes/site_header.html.twig"), "themes/custom/commerce_2_demo/templates/pages/page--product.html.twig", 50)->display($context);
        // line 52
        echo "
";
        // line 54
        echo "<div class=\"site-content\">
  <div class=\"container\">
    <div class=\"row\">
      <div class=\"col-sm-12\">
        <main class=\"content__main-content clearfix\" role=\"main\">
          <div class=\"visually-hidden\"><a id=\"main-content\" tabindex=\"-1\"></a></div>
          ";
        // line 60
        if ($this->getAttribute(($context["page"] ?? null), "highlighted", array())) {
            // line 61
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "highlighted", array()), "html", null, true));
            echo "
          ";
        }
        // line 63
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "above_content", array())) {
            // line 64
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "above_content", array()), "html", null, true));
            echo "
          ";
        }
        // line 66
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "content", array())) {
            // line 67
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "content", array()), "html", null, true));
            echo "
          ";
        }
        // line 69
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "below_content", array())) {
            // line 70
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "below_content", array()), "html", null, true));
            echo "
          ";
        }
        // line 72
        echo "        </main>
      </div>
    </div>
  </div>
</div>
";
        // line 78
        echo "
";
        // line 80
        $this->loadTemplate(((($context["base_path"] ?? null) . ($context["directory"] ?? null)) . "/templates/pages/includes/site_footer.html.twig"), "themes/custom/commerce_2_demo/templates/pages/page--product.html.twig", 80)->display($context);
    }

    public function getTemplateName()
    {
        return "themes/custom/commerce_2_demo/templates/pages/page--product.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 80,  101 => 78,  94 => 72,  88 => 70,  85 => 69,  79 => 67,  76 => 66,  70 => 64,  67 => 63,  61 => 61,  59 => 60,  51 => 54,  48 => 52,  46 => 50,  43 => 48,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/commerce_2_demo/templates/pages/page--product.html.twig", "/home/drupalcommerce/www/demo/web/themes/custom/commerce_2_demo/templates/pages/page--product.html.twig");
    }
}
