<?php

/* themes/custom/commerce_2_demo/templates/pages/page--products.html.twig */
class __TwigTemplate_128dc432c75fdf8817fa457b878d2007ead12353b70836d938d8edd4dbc313de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("set" => 53, "include" => 59, "if" => 63);
        $filters = array("t" => 68);
        $functions = array("render_var" => 53);

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('set', 'include', 'if'),
                array('t'),
                array('render_var')
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 53
        $context["page_sidebar_rendered"] = $this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->getAttribute(($context["page"] ?? null), "page_sidebar", array()));
        // line 55
        $context["row_class"] = ((($context["page_sidebar_rendered"] ?? null)) ? ("row-eq-height") : (""));
        // line 56
        $context["col_class"] = ((($context["page_sidebar_rendered"] ?? null)) ? ("col-sm-9 col-md-10") : ("col-sm-12"));
        // line 57
        echo "
";
        // line 59
        $this->loadTemplate(((($context["base_path"] ?? null) . ($context["directory"] ?? null)) . "/templates/pages/includes/site_header.html.twig"), "themes/custom/commerce_2_demo/templates/pages/page--products.html.twig", 59)->display($context);
        // line 61
        echo "
";
        // line 63
        if (($context["page_sidebar_rendered"] ?? null)) {
            // line 64
            echo "  <div class=\"visible-xs\">
    <aside class=\"site-sidebar site-sidebar--mobile\" role=\"complementary\">
      <div id=\"mobile-sidebar__toggle-open\">
        <a href=\"#\" class=\"btn btn-default\">
          ";
            // line 68
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Products Filters")));
            echo " &nbsp; <i class=\"fa fa-get-pocket fa-lg\"></i>
        </a>
      </div>

      <div id=\"mobile-sidebar__product-filters\">
        ";
            // line 73
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "page_sidebar", array()), "html", null, true));
            echo "

        <div id=\"mobile-sidebar__toggle-close\">
          <a href=\"#\" class=\"btn btn-default\">
            ";
            // line 77
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Close")));
            echo " <i class=\"fa fa-close fa-lg\"></i>
          </a>
        </div>
      </div>
    </aside>
  </div>
";
        }
        // line 84
        echo "
";
        // line 86
        echo "<div class=\"site-content\">
  <div class=\"container\">
    <div class=\"row ";
        // line 88
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["row_class"] ?? null), "html", null, true));
        echo "\">
      ";
        // line 89
        if (($context["page_sidebar_rendered"] ?? null)) {
            // line 90
            echo "        <div class=\"col-sm-3 col-md-2 hidden-xs\">
          <aside class=\"site-sidebar\" role=\"complementary\">
            ";
            // line 92
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "page_sidebar", array()), "html", null, true));
            echo "
          </aside>
        </div>
      ";
        }
        // line 96
        echo "
      <div class=\"";
        // line 97
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["col_class"] ?? null), "html", null, true));
        echo "\">
        <main class=\"content__main-content clearfix\" role=\"main\">
          ";
        // line 100
        echo "          <div class=\"visually-hidden\"><a id=\"main-content\" tabindex=\"-1\"></a></div>
          ";
        // line 101
        if ($this->getAttribute(($context["page"] ?? null), "highlighted", array())) {
            // line 102
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "highlighted", array()), "html", null, true));
            echo "
          ";
        }
        // line 104
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "above_content", array())) {
            // line 105
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "above_content", array()), "html", null, true));
            echo "
          ";
        }
        // line 107
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "content", array())) {
            // line 108
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "content", array()), "html", null, true));
            echo "
          ";
        }
        // line 110
        echo "          ";
        if ($this->getAttribute(($context["page"] ?? null), "below_content", array())) {
            // line 111
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "below_content", array()), "html", null, true));
            echo "
          ";
        }
        // line 113
        echo "        </main>
      </div>
    </div>
  </div>
</div>
";
        // line 119
        echo "
";
        // line 121
        $this->loadTemplate(((($context["base_path"] ?? null) . ($context["directory"] ?? null)) . "/templates/pages/includes/site_footer.html.twig"), "themes/custom/commerce_2_demo/templates/pages/page--products.html.twig", 121)->display($context);
    }

    public function getTemplateName()
    {
        return "themes/custom/commerce_2_demo/templates/pages/page--products.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  170 => 121,  167 => 119,  160 => 113,  154 => 111,  151 => 110,  145 => 108,  142 => 107,  136 => 105,  133 => 104,  127 => 102,  125 => 101,  122 => 100,  117 => 97,  114 => 96,  107 => 92,  103 => 90,  101 => 89,  97 => 88,  93 => 86,  90 => 84,  80 => 77,  73 => 73,  65 => 68,  59 => 64,  57 => 63,  54 => 61,  52 => 59,  49 => 57,  47 => 56,  45 => 55,  43 => 53,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/commerce_2_demo/templates/pages/page--products.html.twig", "/home/drupalcommerce/www/demo/web/themes/custom/commerce_2_demo/templates/pages/page--products.html.twig");
    }
}
